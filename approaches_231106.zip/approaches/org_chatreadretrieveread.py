from text import nonewlines

import openai
from azure.search.documents import SearchClient
from azure.search.documents.models import QueryType
from approaches.approach import Approach
from approaches.chatlogging import write_chatlog, ApproachType
from core.messagebuilder import MessageBuilder
from core.modelhelper import get_gpt_model, get_max_token_from_messages

#//$//
from logging import getLogger, Formatter, FileHandler, DEBUG, INFO
formatter = Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
file_handler = FileHandler("./approaches/org_chatreadretrieveread.log")
file_handler.setFormatter(formatter)
main_logger = getLogger(__name__)
main_logger.addHandler(file_handler)
main_logger.setLevel(DEBUG)
#//$//

# Simple retrieve-then-read implementation, using the Cognitive Search and OpenAI APIs directly. It first retrieves
# top documents from search, then constructs a prompt with them, and then uses OpenAI to generate an completion 
# (answer) with that prompt.
class ChatReadRetrieveReadApproach(Approach):
    # Chat roles
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"

    """
    Simple retrieve-then-read implementation, using the Cognitive Search and OpenAI APIs directly. It first retrieves
    top documents from search, then constructs a prompt with them, and then uses OpenAI to generate an completion
    (answer) with that prompt.
    """
    
    system_message_chat_conversation = """Assistant helps the customer questions. Be brief in your answers.
Answer ONLY with the facts listed in the list of sources below. If there isn't enough information below, say you don't know. Do not generate answers that don't use the sources below. If asking a clarifying question to the user would help, ask the question.
For tabular information return it as an html table. Do not return markdown format. If the question is not in English, answer in the language used in the question.
Each source has a name followed by colon and the actual information, always include the source name for each fact you use in the response. Use square brackets to reference the source, e.g. [info1.txt]. Don't combine sources, list each source separately, e.g. [info1.txt][info2.pdf].
"""
    # アシスタントは顧客の質問を支援します。回答は簡潔にしてください。
    # 以下の情報源リストに記載されている事実のみで回答してください。もし十分な情報が下記にない場合は、わからないと言ってください。下記の情報源を使用しない回答は生成しないでください。ユーザーに確認の質問をすることが助けになる場合は、質問をしてください。
    # 表形式の情報については、HTMLテーブルとして返してください。マークダウン形式で返さないでください。質問が英語でない場合は、質問に使用されている言語で回答してください。
    # 各情報源には、名前に続けてコロンと実際の情報があります。回答で使用する各事実について情報源の名前を常に含めてください。情報源を参照するには角括弧を使用してください。例：[info1.txt]。情報源を組み合わせないで、個別にリストしてください。例：[info1.txt][info2.pdf]。
    
    query_prompt_template = """Below is a history of the conversation so far, and a new question asked by the user that needs to be answered by searching in a knowledge base.
Generate a search query based on the conversation and the new question.
Do not include cited source filenames and document names e.g info.txt or doc.pdf in the search query terms.
Do not include any text inside [] or <<>> in the search query terms.
Do not include any special characters like '+'.
The language of the search query is generated in the language of the string described in the source question.
If you cannot generate a search query, return just the number 0.

source quesion: {user_question}
"""
    # これまでの会話の履歴と、ユーザーが質問した新しい質問が以下にあります。ナレッジベースで検索して答える必要があります。
    # 会話と新しい質問に基づいて検索クエリを生成してください。
    # 検索クエリの用語に、引用されたソースファイル名やドキュメント名（例：info.txt や doc.pdf）は含めないでください。
    # 検索クエリの用語に、[] や <<>> 内のテキストは含めないでください。
    # 検索クエリの用語に、'+' のような特殊文字は含めないでください。
    # 検索クエリの言語は、元の質問で述べられている文字列の言語で生成されます。
    # 検索クエリを生成できない場合は、数字の 0 のみを返してください。

    query_prompt_few_shots = [
        {'role' : USER, 'content' : 'What are my health plans?' },
        {'role' : ASSISTANT, 'content' : 'Show available health plans' },
        {'role' : USER, 'content' : 'does my plan cover cardio?' },
        {'role' : ASSISTANT, 'content' : 'Health plan cardio coverage' }
    ]

    def __init__(self, search_client: SearchClient, sourcepage_field: str, content_field: str):
        self.search_client = search_client  # <SearchClient [endpoint='https://gptkb-jvuf7knsnar76.search.windows.net', index='gptkbindex']>
        self.sourcepage_field = sourcepage_field #  sourcepage
        self.content_field = content_field  # content
        
        #//$//
        main_logger.debug("### Constructor ###")
        main_logger.debug('search_client - {} - {}'.format(type(search_client), search_client))
        main_logger.debug('sourcepage_field - {} - {}'.format(type(sourcepage_field), sourcepage_field))
        main_logger.debug('content_field - {} - {}'.format(type(content_field), content_field))
        #//$//
    
    def run(self, user_name: str, history: list[dict], overrides: dict) -> any:
        # user_name : anonymous
        # history : [{'user': '休暇にはどんな種類がありますか？'}]
        # overrides : {'gptModel': 'gpt-3.5-turbo', 'temperature': '0.0', 'top': 5, 'semanticRanker': True, 'semanticCaptions': True}
        chat_model = overrides.get("gptModel") # gpt-3.5-turbo
        chat_gpt_model = get_gpt_model(chat_model) # {'deployment': 'gpt-35-turbo-deploy', 'max_tokens': 4096, 'encoding': <Encoding 'cl100k_base'>}
        chat_deployment = chat_gpt_model.get("deployment") # gpt-35-turbo-deploy

        #
        # STEP 1: Generate an optimized keyword search query based on the chat history and the last question
        #
        user_q = 'Generate search query for: ' + history[-1]["user"]  # Generate search query for: 休暇にはどんな種類がありますか？
        query_prompt = self.query_prompt_template.format(user_question=history[-1]["user"])  # 上のプロンプトのsource quesionに「休暇にはどんな種類がありますか？」を挿入したもの
        message_builder = MessageBuilder(query_prompt) # <core.messagebuilder.MessageBuilder object at 0x126dd5490>
        messages = message_builder.get_messages_from_history( # [{'role': 'system', 'content': "Below is a history of the conversation so far, and a new question asked by the user that needs to be answered by searching in a knowledge base.\nGenerate a search query based on the conversation and the new question.\nDo not include cited source filenames and document names e.g info.txt or doc.pdf in the search query terms.\nDo not include any text inside [] or <<>> in the search query terms.\nDo not include any special characters like '+'.\nThe language of the search query is generated in the language of the string described in the source question.\nIf you cannot generate a search query, return just the number 0.\n\nsource quesion: 休暇にはどんな種類がありますか？\n"}, {'role': 'assistant', 'content': 'Health plan cardio coverage'}, {'role': 'user', 'content': 'does my plan cover cardio?'}, {'role': 'assistant', 'content': 'Show available health plans'}, {'role': 'user', 'content': 'What are my health plans?'}, {'role': 'user', 'content': 'Generate search query for: 休暇にはどんな種類がありますか？'}]
            history,
            user_q,
            self.query_prompt_few_shots
            )

        max_tokens =  get_max_token_from_messages(messages, chat_model) # 3825

        # Change create type ChatCompletion.create → ChatCompletion.acreate when enabling asynchronous support.
        chat_completion = openai.ChatCompletion.create(
            engine=chat_deployment, 
            messages=messages,
            temperature=0.0,
            max_tokens=max_tokens,
            n=1)
        # {   
        #   "choices": [
        #     {
        #       "finish_reason": "stop",
        #       "index": 0,
        #       "message": {
        #         "content": "\u4f11\u6687\u306e\u7a2e\u985e",
        #         "role": "assistant"
        #       }
        #     }
        #   ],
        #   "created": 1698916746,
        #   "id": "chatcmpl-8GO8w1BYK6GrxjuEVgKymmmmU5uWU",
        #   "model": "gpt-35-turbo",
        #   "object": "chat.completion",
        #   "usage": {
        #     "completion_tokens": 9,
        #     "prompt_tokens": 219,
        #     "total_tokens": 228
        #   }
        # }

        query_text = chat_completion.choices[0].message.content # 休暇の種類
        if query_text.strip() == "0":
            query_text = history[-1]["user"] # Use the last user input if we failed to generate a better query

        total_tokens = chat_completion.usage.total_tokens  # 228
        
        #//$//
        main_logger.debug("### STEP 1: Generate an optimized keyword search query based on the chat history and the last question ###")
        main_logger.debug('user_name - {} - {}'.format(type(user_name), user_name))
        main_logger.debug('history - {} - {}'.format(type(history), history))
        main_logger.debug('overrides - {} - {}'.format(type(overrides), overrides))
        main_logger.debug('chat_model - {} - {}'.format(type(chat_model), chat_model))
        main_logger.debug('chat_gpt_model - {} - {}'.format(type(chat_gpt_model), chat_gpt_model))
        main_logger.debug('chat_deployment - {} - {}'.format(type(chat_deployment), chat_deployment))
        main_logger.debug('user_q - {} - {}'.format(type(user_q), user_q))
        main_logger.debug('query_prompt - {} - {}'.format(type(query_prompt), query_prompt))
        main_logger.debug('message_builder - {} - {}'.format(type(message_builder), message_builder))
        main_logger.debug('messages - {} - {}'.format(type(messages), messages))
        main_logger.debug('max_tokens - {} - {}'.format(type(max_tokens), max_tokens))
        main_logger.debug('chat_completion - {} - {}'.format(type(chat_completion), chat_completion))
        main_logger.debug('query_text - {} - {}'.format(type(query_text), query_text))
        main_logger.debug('total_tokens - {} - {}'.format(type(total_tokens), total_tokens))
        #//$//


        #
        # STEP 2: Retrieve relevant documents from the search index with the GPT optimized query
        #
        use_semantic_captions = True if overrides.get("semanticCaptions") else False  # True
        top = overrides.get("top")  # 5
        exclude_category = overrides.get("excludeCategory") or None  # None
        filter = "category ne '{}'".format(exclude_category.replace("'", "''")) if exclude_category else None  # None
        semantic_ranker = overrides.get("semanticRanker")  # True

        if semantic_ranker:  # True
            r = self.search_client.search(query_text,
                                          filter=filter,
                                          query_type=QueryType.SEMANTIC,
                                          query_language="en-us",
                                          query_speller="lexicon",
                                          semantic_configuration_name="default",
                                          top=top,
                                          query_caption="extractive|highlight-false" if use_semantic_captions else None
                                          )
        else:
            r = self.search_client.search(query_text,
                                          filter=filter,
                                          top=top
                                          )
        if use_semantic_captions:  # True
            results = [doc[self.sourcepage_field] + ": " + nonewlines(" . ".join([c.text for c in doc['@search.captions']])) for doc in r]
        else:
            results = [doc[self.sourcepage_field] + ": " + nonewlines(doc[self.content_field]) for doc in r]
        content = "\n".join(results)
        
        # results - ['001018385-60.pdf: 産前産後の休業期間、育児時間、生理休暇、母性健康管理のための休暇、育児・介護 休業法に基づく育児休業期間、介護休業期間、子の看護休暇期間及び介護休暇期間、慶 弔休暇、病気休暇、裁判員等のための休暇の期間、休職の期間を無給とするか有給とす るかについては、各事業場において決め、就業規則に定めてください。 また、有給とする場合は、例えば「通常の賃金を支払う」、 「基本給の○○％を支払 う」とするなど、できるだけ具体的に定めてください。 ２ （臨時休業の賃金） 第４４条 会社側の都合により、所定労働日に労働者を休業させた場合は、休業１日に つき労基法第１２条に規定する平均賃金の６割を支給する。', '001018385-42.pdf: なお、休暇は暦日単位の ほか半日単位、時間単位でもあっても差し支えありません。 （育児・介護休業、子の看護休暇等） 第２８条 労働者のうち必要のある者は、育児・介護休業法に基づく育児休業、出生時 育児休業、介護休業、子の看護休暇、介護休暇、育児・介護のための所定外労働、時 間外労働及び深夜業の制限並びに所定労働時間の短縮措置等（以下「育児・介護休業 等」という。 ）の適用を受けることができる。 ２ 育児・介護休業等の取扱いについては、「育児・介護休業等に関する規則」で定める。 【第２８条 育児・介護休業、子の看護休暇等】 １ 育児・介護休業、子の看護休暇等に関する事項について、本規程例では就業規則本体 とは別に定める形式をとっています。 「育児・介護休業法について」は、こちらになります。', '001018385-59.pdf: （休暇等の賃金） 第４３条 年次有給休暇の期間は、所定労働時間労働したときに支払われる通常の賃金 を支払う。 ２ 産前産後の休業期間、育児時間、生理休暇、母性健康管理のための休暇、育児・介 護休業法に基づく育児休業期間、介護休業期間、子の看護休暇期間及び介護休暇期間、 慶弔休暇、病気休暇、裁判員等のための休暇の期間は、無給／ 通常の賃金を支払 うこと とする。 ３ 第９条に定める休職期間中は、原則として賃金を支給しない（ を支給する）。', '001018385-35.pdf: （年次有給休暇） 第２３条 採用日から６か月間継続勤務し、所定労働日の８割以上出勤した労働者に対 しては、 １０日の年次有給休暇を与える。 その後１年間継続勤務するごとに、当該１ 年間において所定労働日の８割以上出勤した労働者に対しては、下の表のとおり勤続 期間に応じた日数の年次有給休暇を与える。', '001018385-43.pdf: ① 本人が結婚したとき 日 ② 妻が出産したとき 日 ③ 配偶者、子又は父母が死亡したとき 日 ④ 兄弟姉妹、祖父母、配偶者の父母又は兄弟姉妹が死亡したとき 日 （病気休暇） 第３１条 労働者が私的な負傷又は疾病のため療養する必要があり、その勤務しないこ とがやむを得ないと認められる場合に、病気休暇を 日与える。 【第３０条 慶弔休暇】 【第３１条 病気休暇】 慶弔休暇及び病気休暇については労基法上必ず定めなければならないものではありま せん。 各事業場で必要な期間を具体的に定めてください。']
        
        # content
        # 001018385-60.pdf: 産前産後の休業期間、育児時間、生理休暇、母性健康管理のための休暇、育児・介護 休業法に基づく育児休業期間、介護休業期間、子の看護休暇期間及び介護休暇期間、慶 弔休暇、病気休暇、裁判員等のための休暇の期間、休職の期間を無給とするか有給とす るかについては、各事業場において決め、就業規則に定めてください。 また、有給とする場合は、例えば「通常の賃金を支払う」、 「基本給の○○％を支払 う」とするなど、できるだけ具体的に定めてください。 ２ （臨時休業の賃金） 第４４条 会社側の都合により、所定労働日に労働者を休業させた場合は、休業１日に つき労基法第１２条に規定する平均賃金の６割を支給する。
        # 001018385-42.pdf: なお、休暇は暦日単位の ほか半日単位、時間単位でもあっても差し支えありません。 （育児・介護休業、子の看護休暇等） 第２８条 労働者のうち必要のある者は、育児・介護休業法に基づく育児休業、出生時 育児休業、介護休業、子の看護休暇、介護休暇、育児・介護のための所定外労働、時 間外労働及び深夜業の制限並びに所定労働時間の短縮措置等（以下「育児・介護休業 等」という。 ）の適用を受けることができる。 ２ 育児・介護休業等の取扱いについては、「育児・介護休業等に関する規則」で定める。 【第２８条 育児・介護休業、子の看護休暇等】 １ 育児・介護休業、子の看護休暇等に関する事項について、本規程例では就業規則本体 とは別に定める形式をとっています。 「育児・介護休業法について」は、こちらになります。
        # 001018385-59.pdf: （休暇等の賃金） 第４３条 年次有給休暇の期間は、所定労働時間労働したときに支払われる通常の賃金 を支払う。 ２ 産前産後の休業期間、育児時間、生理休暇、母性健康管理のための休暇、育児・介 護休業法に基づく育児休業期間、介護休業期間、子の看護休暇期間及び介護休暇期間、 慶弔休暇、病気休暇、裁判員等のための休暇の期間は、無給／ 通常の賃金を支払 うこと とする。 ３ 第９条に定める休職期間中は、原則として賃金を支給しない（ を支給する）。
        # 001018385-35.pdf: （年次有給休暇） 第２３条 採用日から６か月間継続勤務し、所定労働日の８割以上出勤した労働者に対 しては、 １０日の年次有給休暇を与える。 その後１年間継続勤務するごとに、当該１ 年間において所定労働日の８割以上出勤した労働者に対しては、下の表のとおり勤続 期間に応じた日数の年次有給休暇を与える。
        # 001018385-43.pdf: ① 本人が結婚したとき 日 ② 妻が出産したとき 日 ③ 配偶者、子又は父母が死亡したとき 日 ④ 兄弟姉妹、祖父母、配偶者の父母又は兄弟姉妹が死亡したとき 日 （病気休暇） 第３１条 労働者が私的な負傷又は疾病のため療養する必要があり、その勤務しないこ とがやむを得ないと認められる場合に、病気休暇を 日与える。 【第３０条 慶弔休暇】 【第３１条 病気休暇】 慶弔休暇及び病気休暇については労基法上必ず定めなければならないものではありま せん。 各事業場で必要な期間を具体的に定めてください。
        
        #//$//
        main_logger.debug("### STEP 2: Retrieve relevant documents from the search index with the GPT optimized query ###")
        main_logger.debug('use_semantic_captions - {} - {}'.format(type(use_semantic_captions), use_semantic_captions))
        main_logger.debug('top - {} - {}'.format(type(top), top))
        main_logger.debug('exclude_category - {} - {}'.format(type(exclude_category), exclude_category))
        main_logger.debug('filter - {} - {}'.format(type(filter), filter))
        main_logger.debug('semantic_ranker - {} - {}'.format(type(semantic_ranker), semantic_ranker))
        main_logger.debug('results - {} - {}'.format(type(results), results))
        main_logger.debug('content - {} - {}'.format(type(content), content))
        #//$//


        #
        # STEP 3: Generate a contextual and content specific answer using the search results and chat history
        #
        # GPT-3.5 Turbo (4k/16k)
        if "gpt-3.5-turbo" in chat_model:
            completion_model = chat_model
            # completion_model = "gpt-35-turbo-instruct" # for future use
        # GPT-4 (8k/32k)
        else:
            completion_model = chat_model
            
        # completion_model - gpt-3.5-turbo

        completion_gpt_model = get_gpt_model(completion_model)  # {'deployment': 'gpt-35-turbo-deploy', 'max_tokens': 4096, 'encoding': <Encoding 'cl100k_base'>}
        completion_deployment = completion_gpt_model.get("deployment")  # gpt-35-turbo-deploy

        message_builder = MessageBuilder(self.system_message_chat_conversation) # <core.messagebuilder.MessageBuilder object at 0x1114011d0>
        messages = message_builder.get_messages_from_history(  # [{'role': 'system', 'content': "Assistant helps the customer questions. Be brief in your answers.\nAnswer ONLY with the facts listed in the list of sources below. If there isn't enough information below, say you don't know. Do not generate answers that don't use the sources below. If asking a clarifying question to the user would help, ask the question.\nFor tabular information return it as an html table. Do not return markdown format. If the question is not in English, answer in the language used in the question.\nEach source has a name followed by colon and the actual information, always include the source name for each fact you use in the response. Use square brackets to reference the source, e.g. [info1.txt]. Don't combine sources, list each source separately, e.g. [info1.txt][info2.pdf].\n"}, {'role': 'user', 'content': '休暇にはどんな種類がありますか？\n\nSources:\n001018385-60.pdf: 産前産後の休業期間、育児時間、生理休暇、母性健康管理のための休暇、育児・介護 休業法に基づく育児休業期間、介護休業期間、子の看護休暇期間及び介護休暇期間、慶 弔休暇、病気休暇、裁判員等のための休暇の期間、休職の期間を無給とするか有給とす るかについては、各事業場において決め、就業規則に定めてください。 また、有給とする場合は、例えば「通常の賃金を支払う」、 「基本給の○○％を支払 う」とするなど、できるだけ具体的に定めてください。 ２ （臨時休業の賃金） 第４４条 会社側の都合により、所定労働日に労働者を休業させた場合は、休業１日に つき労基法第１２条に規定する平均賃金の６割を支給する。\n001018385-42.pdf: なお、休暇は暦日単位の ほか半日単位、時間単位でもあっても差し支えありません。 （育児・介護休業、子の看護休暇等） 第２８条 労働者のうち必要のある者は、育児・介護休業法に基づく育児休業、出生時 育児休業、介護休業、子の看護休暇、介護休暇、育児・介護のための所定外労働、時 間外労働及び深夜業の制限並びに所定労働時間の短縮措置等（以下「育児・介護休業 等」という。 ）の適用を受けることができる。 ２ 育児・介護休業等の取扱いについては、「育児・介護休業等に関する規則」で定める。 【第２８条 育児・介護休業、子の看護休暇等】 １ 育児・介護休業、子の看護休暇等に関する事項について、本規程例では就業規則本体 とは別に定める形式をとっています。 「育児・介護休業法について」は、こちらになります。\n001018385-59.pdf: （休暇等の賃金） 第４３条 年次有給休暇の期間は、所定労働時間労働したときに支払われる通常の賃金 を支払う。 ２ 産前産後の休業期間、育児時間、生理休暇、母性健康管理のための休暇、育児・介 護休業法に基づく育児休業期間、介護休業期間、子の看護休暇期間及び介護休暇期間、 慶弔休暇、病気休暇、裁判員等のための休暇の期間は、無給／ 通常の賃金を支払 うこと とする。 ３ 第９条に定める休職期間中は、原則として賃金を支給しない（ を支給する）。\n001018385-35.pdf: （年次有給休暇） 第２３条 採用日から６か月間継続勤務し、所定労働日の８割以上出勤した労働者に対 しては、 １０日の年次有給休暇を与える。 その後１年間継続勤務するごと'}]
            history,
            history[-1]["user"]+ "\n\nSources:\n" + content[:1024], # Model does not handle lengthy system messages well. Moving sources to latest user conversation to solve follow up questions prompt.
            )
        # [
        # {'role': 'system', 'content': "Assistant helps the customer questions. Be brief in your answers.\nAnswer ONLY with the facts listed in the list of sources below. If there isn't enough information below, say you don't know. Do not generate answers that don't use the sources below. If asking a clarifying question to the user would help, ask the question.\nFor tabular information return it as an html table. Do not return markdown format. If the question is not in English, answer in the language used in the question.\nEach source has a name followed by colon and the actual information, always include the source name for each fact you use in the response. Use square brackets to reference the source, e.g. [info1.txt]. Don't combine sources, list each source separately, e.g. [info1.txt][info2.pdf].\n"}, 
        # {'role': 'user', 'content': '休暇にはどんな種類がありますか？\n\nSources:\n001018385-60.pdf: 産前産後の休業期間、育児時間、生理休暇、母性健康管理のための休暇、育児・介護 休業法に基づく育児休業期間、介護休業期間、子の看護休暇期間及び介護休暇期間、慶 弔休暇、病気休暇、裁判員等のための休暇の期間、休職の期間を無給とするか有給とす るかについては、各事業場において決め、就業規則に定めてください。 また、有給とする場合は、例えば「通常の賃金を支払う」、 「基本給の○○％を支払 う」とするなど、できるだけ具体的に定めてください。 ２ （臨時休業の賃金） 第４４条 会社側の都合により、所定労働日に労働者を休業させた場合は、休業１日に つき労基法第１２条に規定する平均賃金の６割を支給する。\n001018385-42.pdf: なお、休暇は暦日単位の ほか半日単位、時間単位でもあっても差し支えありません。 （育児・介護休業、子の看護休暇等） 第２８条 労働者のうち必要のある者は、育児・介護休業法に基づく育児休業、出生時 育児休業、介護休業、子の看護休暇、介護休暇、育児・介護のための所定外労働、時 間外労働及び深夜業の制限並びに所定労働時間の短縮措置等（以下「育児・介護休業 等」という。 ）の適用を受けることができる。 ２ 育児・介護休業等の取扱いについては、「育児・介護休業等に関する規則」で定める。 【第２８条 育児・介護休業、子の看護休暇等】 １ 育児・介護休業、子の看護休暇等に関する事項について、本規程例では就業規則本体 とは別に定める形式をとっています。 「育児・介護休業法について」は、こちらになります。\n001018385-59.pdf: （休暇等の賃金） 第４３条 年次有給休暇の期間は、所定労働時間労働したときに支払われる通常の賃金 を支払う。 ２ 産前産後の休業期間、育児時間、生理休暇、母性健康管理のための休暇、育児・介 護休業法に基づく育児休業期間、介護休業期間、子の看護休暇期間及び介護休暇期間、 慶弔休暇、病気休暇、裁判員等のための休暇の期間は、無給／ 通常の賃金を支払 うこと とする。 ３ 第９条に定める休職期間中は、原則として賃金を支給しない（ を支給する）。\n001018385-35.pdf: （年次有給休暇） 第２３条 採用日から６か月間継続勤務し、所定労働日の８割以上出勤した労働者に対 しては、 １０日の年次有給休暇を与える。 その後１年間継続勤務するごと'}
        # ]
        
        temaperature = float(overrides.get("temperature")) # 0.0
        max_tokens = get_max_token_from_messages(messages, completion_model)  # 2667

        # Change create type ChatCompletion.create → ChatCompletion.acreate when enabling asynchronous support.
        response = openai.ChatCompletion.create(
            engine=completion_deployment, 
            messages=messages,
            temperature=temaperature,
            max_tokens=1024,
            n=1)
        
        # {
        #   "choices": [
        #     {
        #       "finish_reason": "stop",
        #       "index": 0,
        #       "message": {
        #         "content": "\u4f11\u6687\u306e\u7a2e\u985e\u306f\u4ee5\u4e0b\u306e\u901a\u308a\u3067\u3059\uff1a\n- \u7523\u524d\u7523\u5f8c\u306e\u4f11\u696d\u671f\u9593\n- \u80b2\u5150\u6642\u9593\n- \u751f\u7406\u4f11\u6687\n- \u6bcd\u6027\u5065\u5eb7\u7ba1\u7406\u306e\u305f\u3081\u306e\u4f11\u6687\n- \u80b2\u5150\u30fb\u4ecb\u8b77\u4f11\u696d\u6cd5\u306b\u57fa\u3065\u304f\u80b2\u5150\u4f11\u696d\u671f\u9593\n- \u4ecb\u8b77\u4f11\u696d\u671f\u9593\n- \u5b50\u306e\u770b\u8b77\u4f11\u6687\u671f\u9593\u53ca\u3073\u4ecb\u8b77\u4f11\u6687\u671f\u9593\n- \u6176\u5f14\u4f11\u6687\n- \u75c5\u6c17\u4f11\u6687\n- \u88c1\u5224\u54e1\u7b49\u306e\u305f\u3081\u306e\u4f11\u6687\u306e\u671f\u9593\n- \u4f11\u8077\u306e\u671f\u9593 [001018385-60.pdf]",
        #         "role": "assistant"
        #       }
        #     }
        #   ],
        #   "created": 1698916748,
        #   "id": "chatcmpl-8GO8yRtqJwvLUJm4tKswk87rSkgGp",
        #   "model": "gpt-35-turbo",
        #   "object": "chat.completion",
        #   "usage": {
        #     "completion_tokens": 195,
        #     "prompt_tokens": 1403,
        #     "total_tokens": 1598
        #   }
        # }
        
        response_text = response.choices[0]["message"]["content"]
        # 休暇の種類は以下の通りです：
        # - 産前産後の休業期間
        # - 育児時間
        # - 生理休暇
        # - 母性健康管理のための休暇
        # - 育児・介護休業法に基づく育児休業期間
        # - 介護休業期間
        # - 子の看護休暇期間及び介護休暇期間
        # - 慶弔休暇
        # - 病気休暇
        # - 裁判員等のための休暇の期間
        # - 休職の期間 [001018385-60.pdf]
        
        total_tokens += response.usage.total_tokens # 1826

        # logging
        input_text = history[-1]["user"] # 休暇にはどんな種類がありますか？
        write_chatlog(ApproachType.DocSearch, user_name, total_tokens, input_text, response_text, query_text)

        msg_to_display = '\n\n'.join([str(message) for message in messages])
        # {'role': 'system', 'content': "Assistant helps the customer questions. Be brief in your answers.\nAnswer ONLY with the facts listed in the list of sources below. If there isn't enough information below, say you don't know. Do not generate answers that don't use the sources below. If asking a clarifying question to the user would help, ask the question.\nFor tabular information return it as an html table. Do not return markdown format. If the question is not in English, answer in the language used in the question.\nEach source has a name followed by colon and the actual information, always include the source name for each fact you use in the response. Use square brackets to reference the source, e.g. [info1.txt]. Don't combine sources, list each source separately, e.g. [info1.txt][info2.pdf].\n"}
        # 改行
        # {'role': 'user', 'content': '休暇にはどんな種類がありますか？\n\nSources:\n001018385-60.pdf: 産前産後の休業期間、育児時間、生理休暇、母性健康管理のための休暇、育児・介護 休業法に基づく育児休業期間、介護休業期間、子の看護休暇期間及び介護休暇期間、慶 弔休暇、病気休暇、裁判員等のための休暇の期間、休職の期間を無給とするか有給とす るかについては、各事業場において決め、就業規則に定めてください。 また、有給とする場合は、例えば「通常の賃金を支払う」、 「基本給の○○％を支払 う」とするなど、できるだけ具体的に定めてください。 ２ （臨時休業の賃金） 第４４条 会社側の都合により、所定労働日に労働者を休業させた場合は、休業１日に つき労基法第１２条に規定する平均賃金の６割を支給する。\n001018385-42.pdf: なお、休暇は暦日単位の ほか半日単位、時間単位でもあっても差し支えありません。 （育児・介護休業、子の看護休暇等） 第２８条 労働者のうち必要のある者は、育児・介護休業法に基づく育児休業、出生時 育児休業、介護休業、子の看護休暇、介護休暇、育児・介護のための所定外労働、時 間外労働及び深夜業の制限並びに所定労働時間の短縮措置等（以下「育児・介護休業 等」という。 ）の適用を受けることができる。 ２ 育児・介護休業等の取扱いについては、「育児・介護休業等に関する規則」で定める。 【第２８条 育児・介護休業、子の看護休暇等】 １ 育児・介護休業、子の看護休暇等に関する事項について、本規程例では就業規則本体 とは別に定める形式をとっています。 「育児・介護休業法について」は、こちらになります。\n001018385-59.pdf: （休暇等の賃金） 第４３条 年次有給休暇の期間は、所定労働時間労働したときに支払われる通常の賃金 を支払う。 ２ 産前産後の休業期間、育児時間、生理休暇、母性健康管理のための休暇、育児・介 護休業法に基づく育児休業期間、介護休業期間、子の看護休暇期間及び介護休暇期間、 慶弔休暇、病気休暇、裁判員等のための休暇の期間は、無給／ 通常の賃金を支払 うこと とする。 ３ 第９条に定める休職期間中は、原則として賃金を支給しない（ を支給する）。\n001018385-35.pdf: （年次有給休暇） 第２３条 採用日から６か月間継続勤務し、所定労働日の８割以上出勤した労働者に対 しては、 １０日の年次有給休暇を与える。 その後１年間継続勤務するごと'}

        
        #//$//
        main_logger.debug("### STEP 3: Generate a contextual and content specific answer using the search results and chat history ###")
        main_logger.debug('completion_model - {} - {}'.format(type(completion_model), completion_model))
        main_logger.debug('completion_gpt_model - {} - {}'.format(type(completion_gpt_model), completion_gpt_model))
        main_logger.debug('completion_deployment - {} - {}'.format(type(completion_deployment), completion_deployment))
        main_logger.debug('message_builder - {} - {}'.format(type(message_builder), message_builder))
        main_logger.debug('messages - {} - {}'.format(type(messages), messages))
        main_logger.debug('temaperature - {} - {}'.format(type(temaperature), temaperature))
        main_logger.debug('max_tokens - {} - {}'.format(type(max_tokens), max_tokens))
        main_logger.debug('response - {} - {}'.format(type(response), response))
        main_logger.debug('response_text - {} - {}'.format(type(response_text), response_text))
        main_logger.debug('total_tokens - {} - {}'.format(type(total_tokens), total_tokens))
        main_logger.debug('input_text - {} - {}'.format(type(input_text), input_text))
        main_logger.debug('responsemsg_to_display_text - {} - {}'.format(type(msg_to_display), msg_to_display))
        #//$//

        return {"data_points": results, "answer": response_text, "thoughts": f"Searched for:<br>{query_text}<br><br>Conversations:<br>" + msg_to_display.replace('\n', '<br>')}
        # response_text : チャットの回答
        # query_text : 思考プロセス/Search for/直近の検索用語
        # msg_to_display : 思考プロセス/Conversations/systemプロンプト&userプロンプト
        # results : 補助資料