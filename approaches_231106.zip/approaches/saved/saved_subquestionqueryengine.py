from IPython.display import display
import os
import glob

import nest_asyncio
nest_asyncio.apply()

# import logging
# logging.basicConfig(level=logging.DEBUG)


print("\n************************************************************************************************\n")
print("service_context")
print("\n************************************************************************************************\n")
from langchain.chat_models import ChatOpenAI
from llama_index import ServiceContext

llm = ChatOpenAI(model_name="gpt-4", temperature=0)  # text-davinch → gpt-3.5-turbo , gpt-4
service_context = ServiceContext.from_defaults(llm=llm)

print(service_context)
print()
print(service_context.embed_model)  # 'text-embedding-ada-002'



print("\n************************************************************************************************\n")
print("チャンク化&index作成(VectorStoreIndex) or indexロード")
print("\n************************************************************************************************\n")
from llama_index import SimpleDirectoryReader
from llama_index import VectorStoreIndex

# chunks_stableDiff = SimpleDirectoryReader(input_files=["./data/Stable_Diffusion.pdf"]).load_data() # files
# print(len(chunks_stableDiff))
# display(chunks_stableDiff)
# index_stableDiff = VectorStoreIndex.from_documents(
#     documents=chunks_stableDiff, 
#     service_context=service_context
# )
# display(index_stableDiff)

# chunks_pg_essay = SimpleDirectoryReader(input_dir="./data/paul_graham/").load_data() # directory
# print(len(chunks_pg_essay))
# display(chunks_pg_essay)
# index_pg_essay = VectorStoreIndex.from_documents(
#     documents=chunks_pg_essay, 
#     service_context=service_context
# )
# display(index_pg_essay)

# chunks_10k_SecInsights = SimpleDirectoryReader(input_dir="./data/10k_sec_insights/").load_data() # directory
# print(len(chunks_10k_SecInsights))
# display(chunks_10k_SecInsights)
# index_10k_SecInsights = VectorStoreIndex.from_documents(
#     documents=chunks_10k_SecInsights, 
#     service_context=service_context
# )
# display(index_10k_SecInsights)


if os.path.exists("./index"): 
    print(" ***** indexをロード ***** ")
    from llama_index import StorageContext, load_index_from_storage
    storage_context = StorageContext.from_defaults(persist_dir="./index/")
    index_ports = load_index_from_storage(storage_context)
    display(index_ports)
else:
    print(" ***** チャンク化 ***** ")
    chunks_ports = SimpleDirectoryReader(input_dir="./data/sports/").load_data() # directory
    print(len(chunks_ports))
    # display(chunks_ports)
    print(" ***** indexフォルダを作成 ***** ")
    os.mkdir("./index")
    print(" ***** indexを作成 ***** ")
    index_ports = VectorStoreIndex.from_documents(
        documents=chunks_ports, 
        service_context=service_context,
        use_async=True,
    )
    display(index_ports)
    print(" ***** indexを保存 ***** ")
    index_ports.storage_context.persist(persist_dir="./index/")
    lst_indexFiles = glob.glob("./index/*")
    print(lst_indexFiles)
    


print("\n************************************************************************************************\n")
print("Query Engine")
print("\n************************************************************************************************\n")
# engine_stableDiff = index_stableDiff.as_query_engine()
# engine_pg_essay = index_pg_essay.as_query_engine(similarity_top_k=3)
# engine_10k_SecInsights = index_10k_SecInsights.as_query_engine()
engine_ports = index_ports.as_query_engine(similarity_top_k=3, temperature=0.5)

from llama_index.tools import QueryEngineTool, ToolMetadata
from llama_index.query_engine import SubQuestionQueryEngine
query_engine_tools = [
    QueryEngineTool(
        query_engine=engine_ports,
        metadata=ToolMetadata(
            name="sports", description="sports festivals"
        ),
    ),
]
s_engine = SubQuestionQueryEngine.from_defaults(
    query_engine_tools=query_engine_tools,
    service_context=service_context,
    use_async=True,
)


print("\n************************************************************************************************\n")
print("question")
print("\n************************************************************************************************\n")
# question = "Stable Diffusionを使うにはどのくらいのGPUが必要ですか？"
# question = "How was Paul Grahams life different before, during, and after YC?"
# question = "2022年FIFAサッカーワールドカップの優勝国はどこですか?"
# question = "2022年FIFAワールドカップにおいてMVPは誰が獲得しましたか?"
# question = "2023年WBCの優勝国はどこですか?"
# question = "2023年WBCにおいてMVPは誰が獲得しましたか?"
question = "2022年サッカーワールドカップと2023年WBCと2023年バスケワールドカップにおいて,開催国と優勝国とMVPについて教えてください"
# question = "What issues do the companies face?"

print(question)


print("\n************************************************************************************************\n")
print("Query")
print("\n************************************************************************************************\n")
# response = engine_stableDiff.query(question)
# response = engine_pg_essay.query(question)
# response = engine_10k_SecInsights.query(question)
# response = engine_ports.query(question)

response = s_engine.query(question)


print("\n************************************************************************************************\n")
print("response")
print("\n************************************************************************************************\n")

# 回答の内容を表示
print(response.response)

print()

# 情報ソースの表示
print(len(response.source_nodes))
print(response.source_nodes)

print()

# 情報ソースの表示
print(response.get_formatted_sources())
# print(response.get_formatted_sources(1000)) # 文字数を指定