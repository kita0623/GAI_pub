# 同期処理
# APIキーを隠す
# Cognitive Search
# 履歴考慮

###################
# Github(jp-azureopenai-samples) : https://github.com/Azure-Samples/jp-azureopenai-samples/tree/main
# Github(LlamaIndex) : https://github.com/run-llama/llama_index
# LlamaIndexドキュメント(Azure OpenAI) : https://gpt-index.readthedocs.io/en/latest/examples/customization/llms/AzureOpenAI.html
# LlamaIndexドキュメント(Azure Cognitive Search) : https://gpt-index.readthedocs.io/en/latest/examples/vector_stores/CognitiveSearchIndexDemo.html
###################

import os
import sys
import json

import logging
logging.basicConfig(stream=sys.stdout, level=logging.INFO)
logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))

from text import nonewlines

import openai

from azure.search.documents import SearchClient
from azure.search.documents.models import QueryType
from approaches.approach import Approach
from approaches.chatlogging import write_chatlog, ApproachType
from core.messagebuilder import MessageBuilder
from core.modelhelper import get_gpt_model, get_max_token_from_messages

import nest_asyncio
nest_asyncio.apply()

# from langchain.chat_models import ChatOpenAI
# from llama_index import ServiceContext
# from llama_index import SimpleDirectoryReader
# from llama_index import VectorStoreIndex
# from llama_index.tools import QueryEngineTool, ToolMetadata
# from llama_index.query_engine import SubQuestionQueryEngine


api_key = "ebcc1cf3327842698dfce603cc9a58a8"
api_base = "https://cog-jvuf7knsnar76.openai.azure.com/"
api_type = "azure"
api_version = "2023-09-15-preview"


# Simple retrieve-then-read implementation, using the Cognitive Search and OpenAI APIs directly. It first retrieves
# top documents from search, then constructs a prompt with them, and then uses OpenAI to generate an completion 
# (answer) with that prompt.
class ChatReadRetrieveReadApproach(Approach):
    # Chat roles
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"

    """
    Simple retrieve-then-read implementation, using the Cognitive Search and OpenAI APIs directly. It first retrieves
    top documents from search, then constructs a prompt with them, and then uses OpenAI to generate an completion
    (answer) with that prompt.
    """
    system_message_chat_conversation = """Assistant helps the customer questions. Be brief in your answers.
Answer ONLY with the facts listed in the list of sources below. If there isn't enough information below, say you don't know. Do not generate answers that don't use the sources below. If asking a clarifying question to the user would help, ask the question.
For tabular information return it as an html table. Do not return markdown format. If the question is not in English, answer in the language used in the question.
Each source has a name followed by colon and the actual information, always include the source name for each fact you use in the response. Use square brackets to reference the source, e.g. [info1.txt]. Don't combine sources, list each source separately, e.g. [info1.txt][info2.pdf].
"""
    query_prompt_template = """Below is a history of the conversation so far, and a new question asked by the user that needs to be answered by searching in a knowledge base.
Generate a search query based on the conversation and the new question.
Do not include cited source filenames and document names e.g info.txt or doc.pdf in the search query terms.
Do not include any text inside [] or <<>> in the search query terms.
Do not include any special characters like '+'.
The language of the search query is generated in the language of the string described in the source question.
If you cannot generate a search query, return just the number 0.

source quesion: {user_question}
"""
    query_prompt_few_shots = [
        {'role' : USER, 'content' : 'What are my health plans?' },
        {'role' : ASSISTANT, 'content' : 'Show available health plans' },
        {'role' : USER, 'content' : 'does my plan cover cardio?' },
        {'role' : ASSISTANT, 'content' : 'Health plan cardio coverage' }
    ]

    def __init__(self, search_client: SearchClient, sourcepage_field: str, content_field: str):
        #//$// いずれもSTEP2で使用
        self.search_client = search_client
        self.sourcepage_field = sourcepage_field
        self.content_field = content_field

    
    def run(self, user_name: str, history: list[dict], overrides: dict) -> any:
        
        print("\n************************************************************************************************\n")
        print("ServiceContext")
        print("\n************************************************************************************************\n")
        from llama_index.llms import AzureOpenAI
        llm = AzureOpenAI(
            model="gpt-35-turbo",
            engine="gpt-35-turbo-deploy",
            api_key=api_key,
            api_base=api_base,
            api_type=api_type,
            api_version=api_version,
        )

        from llama_index.embeddings import OpenAIEmbedding
        embed_model = OpenAIEmbedding(
            model="text-embedding-ada-002",
            deployment_name="text-embedding-ada-002-deploy", # Azure AI Studioで作成
            api_key=api_key,
            api_base=api_base,
            api_type=api_type,
            api_version=api_version,
        )

        from llama_index import ServiceContext
        service_context = ServiceContext.from_defaults(
            llm=llm,
            embed_model=embed_model,
        )
        from llama_index import set_global_service_context
        set_global_service_context(service_context) # Helper function to set the global service context


        print("\n************************************************************************************************\n")
        print("SimpleDirectoryReader")
        print("\n************************************************************************************************\n")
        from llama_index import SimpleDirectoryReader
        documents = SimpleDirectoryReader("../../data/").load_data()


        print("\n************************************************************************************************\n")
        print("llama_index.VectorStoreIndex")
        print("\n************************************************************************************************\n")
        from llama_index import VectorStoreIndex
        index = VectorStoreIndex.from_documents(documents)


        # print("\n************************************************************************************************\n")
        # print("Azure Cognitive Search")
        # print("\n************************************************************************************************\n")
        # # set up Azure Cognitive Search
        # from azure.search.documents.indexes import SearchIndexClient
        # from azure.search.documents import SearchClient
        # from azure.core.credentials import AzureKeyCredential

        # search_service_name = getpass.getpass("Azure Cognitive Search Service Name")

        # key = getpass.getpass("Azure Cognitive Search Key")

        # cognitive_search_credential = AzureKeyCredential(key)

        # service_endpoint = f"https://{search_service_name}.search.windows.net"

        # # Index name to use
        # index_name = "quickstart"

        # # Use index client to demonstrate creating an index
        # index_client = SearchIndexClient(
        #     endpoint=service_endpoint,
        #     credential=cognitive_search_credential,
        # )

        # # Use search client to demonstration using existing index
        # search_client = SearchClient(
        #     endpoint=service_endpoint,
        #     index_name=index_name,
        #     credential=cognitive_search_credential,
        # )


        # from azure.search.documents import SearchClient
        # from llama_index.vector_stores import CognitiveSearchVectorStore
        # from llama_index.vector_stores.cogsearch import (
        #     IndexManagement,
        #     MetadataIndexFieldType,
        #     CognitiveSearchVectorStore,
        # )

        # # Example of a complex mapping, metadata field 'theme' is mapped to a differently name index field 'topic' with its type explicitly set
        # metadata_fields = {
        #     "author": "author",
        #     "theme": ("topic", MetadataIndexFieldType.STRING),
        #     "director": "director",
        # }

        # # A simplified metadata specification is available if all metadata and index fields are similarly named
        # # metadata_fields = {"author", "theme", "director"}


        # vector_store = CognitiveSearchVectorStore(
        #     search_or_index_client=index_client,
        #     index_name=index_name,
        #     filterable_metadata_field_keys=metadata_fields,
        #     index_management=IndexManagement.CREATE_IF_NOT_EXISTS,
        #     id_field_key="id",
        #     chunk_field_key="content",
        #     embedding_field_key="embedding",
        #     metadata_string_field_key="li_jsonMetadata",
        #     doc_id_field_key="li_doc_id",
        # )

        # # define embedding function
        # from llama_index.embeddings import OpenAIEmbedding
        # from llama_index import (
        #     SimpleDirectoryReader,
        #     StorageContext,
        #     ServiceContext,
        #     VectorStoreIndex,
        # )

        # embed_model = OpenAIEmbedding()

        # # load documents
        # documents = SimpleDirectoryReader(
        #     "../../../examples/paul_graham_essay/data"
        # ).load_data()

        # storage_context = StorageContext.from_defaults(vector_store=vector_store)
        # service_context = ServiceContext.from_defaults(embed_model=embed_model)
        # index = VectorStoreIndex.from_documents(
        #     documents, storage_context=storage_context, service_context=service_context
        # )


        print("\n************************************************************************************************\n")
        print("Query Engine")
        print("\n************************************************************************************************\n")
        query_engine = index.as_query_engine()

        from llama_index.tools import QueryEngineTool, ToolMetadata
        from llama_index.query_engine import SubQuestionQueryEngine
        query_engine_tools = [
            QueryEngineTool(
                query_engine=query_engine,
                metadata=ToolMetadata(
                    name="sports", description="sports festivals"
                ),
            ),
        ]
        subquery_engine = SubQuestionQueryEngine.from_defaults(
            query_engine_tools=query_engine_tools,
            service_context=service_context,
            use_async=True,
        )


        print("\n************************************************************************************************\n")
        print("question")
        print("\n************************************************************************************************\n")
        # query = "What is most interesting about this essay?"
        # query = "2022年サッカーワールドカップと2023年WBCと2023年バスケワールドカップにおいて,それぞれ優勝国について教えてください"
        # query = "2022年サッカーワールドカップと2023年WBCと2023年バスケワールドカップにおいて,開催国と優勝国とMVPについて教えてください"
        # query = "2023年WBCの優勝国はどこですか？"
        # query = "2022年サッカーワールドカップのMVPは誰ですか？"
        question = history[-1]["user"]
        print(question)


        print("\n************************************************************************************************\n")
        print("Query")
        print("\n************************************************************************************************\n")
        # response = query_engine.query(question)
        response = subquery_engine.query(question)


        print("\n************************************************************************************************\n")
        print("response")
        print("\n************************************************************************************************\n")
        # 回答の内容を表示
        print(response.response)

        print()

        # 情報ソースの表示
        print(len(response.source_nodes))
        print(response.source_nodes)

        print()

        # 情報ソースの表示
        print(response.get_formatted_sources())
        # print(response.get_formatted_sources(1000)) # 文字数を指定


        print("\n************************************************************************************************\n")
        print("Returns")
        print("\n************************************************************************************************\n")
        results = ["dummy of results"]  # 補助資料がdummy of resultsとなる
        msg_to_display = "dummy of msg_to_display"  # 思考プロセスがdummy of msg_to_displayとなる
        query_text = "dummy of query_text" # 思考プロセスがdummy of query_textとなる
        response_text = response.response  # "dummy of response_text" # チャットの回答がdummy of response_textとなる
        
        return {"data_points": results, "answer": response_text, "thoughts": f"Searched for:<br>{query_text}<br><br>Conversations:<br>" + msg_to_display.replace('\n', '<br>')}