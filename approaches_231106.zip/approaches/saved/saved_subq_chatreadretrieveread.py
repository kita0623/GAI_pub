
# TODO-------------------------------------------------------
# 必ずSubQuestionQueryでRAGを実施しているが、チャットの内容に応じて会話できるように (元もそうなっている？)
# 英語で回答が返されたら、日本語に翻訳してから返す (Agentはない？本に日本語変換方法のまとめコラムがあった気がする)
# 会話履歴はLangChainのConversationBufferMemoryを使ってみる(OpenAIのモデルにそのまま渡せる形式)
# 会話履歴はCosmosDBに保存しているようなので、トライしてみる (approaches.chatlogging.write_chatlog)
# FoamRecognizer(デフォルトの実装では使用されているよう)
# service_contextでチャンク分割ルールの変更
# ワールドカップwikiのPDFは表で情報が入っているので例を変えた方がよいかも
# -----------------------------------------------------------
# MEMO-------------------------------------------------------
# python3.9のpyenv環境で実行
# openaiのapiは使用しない
# azd up で全デプロイが実施される (Coginitive Searchのインデックス作成も実施される)  indexをazure上で消したらデフォルトのchatreadretrievereadが動かなくなった
# cognitive searchの"Create Index"と"Use Existing Index"の大きな違いは、existing index と index_client
# Use Existing Index"の場合もservice_contextにLLMを指定する必要があった(LlamaIndexのドキュメントのCognitive Searchの例ではLLMの指定はなかったが)
# -----------------------------------------------------------

import os
import sys
import json

# import logging
# logging.basicConfig(stream=sys.stdout, level=logging.INFO)
# logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))

from logging import getLogger, Formatter, FileHandler, DEBUG, INFO
formatter = Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
file_handler = FileHandler("./approaches/subquestionquery.log")
file_handler.setFormatter(formatter)
main_logger = getLogger(__name__)
main_logger.addHandler(file_handler)
main_logger.setLevel(DEBUG)

from text import nonewlines

import openai

from azure.search.documents import SearchClient
from azure.search.documents.models import QueryType
from approaches.approach import Approach
from approaches.chatlogging import write_chatlog, ApproachType
from core.messagebuilder import MessageBuilder
from core.modelhelper import get_gpt_model, get_max_token_from_messages

import nest_asyncio
nest_asyncio.apply()

# from langchain.chat_models import ChatOpenAI
# from llama_index import ServiceContext
# from llama_index import SimpleDirectoryReader
# from llama_index import VectorStoreIndex
# from llama_index.tools import QueryEngineTool, ToolMetadata
# from llama_index.query_engine import SubQuestionQueryEngine


api_key = "ebcc1cf3327842698dfce603cc9a58a8"
api_base = "https://cog-jvuf7knsnar76.openai.azure.com/"
api_type = "azure"
api_version = "2023-09-15-preview"

FLAG_CREATE_INDEX = False


# Simple retrieve-then-read implementation, using the Cognitive Search and OpenAI APIs directly. It first retrieves
# top documents from search, then constructs a prompt with them, and then uses OpenAI to generate an completion 
# (answer) with that prompt.
class ChatReadRetrieveReadApproach(Approach):

    def __init__(self, search_client: SearchClient, sourcepage_field: str, content_field: str):
        main_logger.debug("### Constructor ###")
    
    
    def run(self, user_name: str, history: list[dict], overrides: dict) -> any:

        ############################################################################################################
        # Azure Cognitive Search
        ############################################################################################################
        main_logger.debug("### Azure Cognitive Search ###")
        from azure.search.documents.indexes import SearchIndexClient
        from azure.search.documents import SearchClient
        from azure.core.credentials import AzureKeyCredential

        ###############
        # Settings
        ###############
        # search_service_name = getpass.getpass("Azure Cognitive Search Service Name")
        search_service_name = os.environ["RG_TEST_KITAMOTO_SUBQUESTIONQUERY_COGNITIVE_SEARCH_NAME"] # 設定したCognitive Searchのサービス名
        # key = getpass.getpass("Azure Cognitive Search Key")
        key = os.environ["RG_TEST_KITAMOTO_SUBQUESTIONQUERY_COGNITIVE_SEARCH_KEY"]

        cognitive_search_credential = AzureKeyCredential(key)
        service_endpoint = f"https://{search_service_name}.search.windows.net"
        index_name = "indextest" # インデックス名はAzureクラウド上に反映される


        if FLAG_CREATE_INDEX:
            
            ########################################################
            # Create Index (if it does not exist)
            ########################################################
            main_logger.debug("### Create Index (if it does not exist) ###")

            ###############
            # documents
            ###############
            from llama_index import SimpleDirectoryReader
            documents = SimpleDirectoryReader("../../data/").load_data()
            
            ###############
            # index_client
            # Use index client to demonstrate creating an index
            ###############
            index_client = SearchIndexClient(
                endpoint=service_endpoint,
                credential=cognitive_search_credential,
            )

            ###############
            # vector_store
            ###############
            from llama_index.vector_stores import CognitiveSearchVectorStore
            from llama_index.vector_stores.cogsearch import (
                IndexManagement,
                MetadataIndexFieldType,
                CognitiveSearchVectorStore,
            )
            # # Example of a complex mapping, metadata field 'theme' is mapped to a differently name index field 'topic' with its type explicitly set
            # metadata_fields = {
            #     "author": "author",
            #     "theme": ("topic", MetadataIndexFieldType.STRING),
            #     "director": "director",
            # }

            # A simplified metadata specification is available if all metadata and index fields are similarly named
            # metadata_fields = {"author", "theme", "director"}
            vector_store = CognitiveSearchVectorStore(
                search_or_index_client=index_client,
                index_name=index_name,
                # filterable_metadata_field_keys=metadata_fields,
                index_management=IndexManagement.CREATE_IF_NOT_EXISTS,
                id_field_key="id",
                chunk_field_key="content",
                embedding_field_key="embedding",
                metadata_string_field_key="li_jsonMetadata",
                doc_id_field_key="li_doc_id",
            )
            
            ###############
            # storage_context
            ###############
            from llama_index import StorageContext
            storage_context = StorageContext.from_defaults(
                vector_store=vector_store
            )

            ###############
            # service_context
            ###############
            from llama_index.llms import AzureOpenAI
            llm = AzureOpenAI(
                model="gpt-35-turbo",
                engine="gpt-35-turbo-deploy",
                api_key=api_key,
                api_base=api_base,
                api_type=api_type,
                api_version=api_version,
            )

            from llama_index.embeddings import OpenAIEmbedding
            embed_model = OpenAIEmbedding(
                model="text-embedding-ada-002",
                deployment_name="text-embedding-ada-002-deploy", # Azure AI Studioで作成
                api_key=api_key,
                api_base=api_base,
                api_type=api_type,
                api_version=api_version,
            )

            from llama_index import ServiceContext
            service_context = ServiceContext.from_defaults(
                llm=llm,
                embed_model=embed_model,
                # prompt_helper でチャンク分割ルールの変更も可能
            )
            # from llama_index import set_global_service_context
            # set_global_service_context(service_context) # Helper function to set the global service context
            
            ###############
            # index
            ###############
            from llama_index import VectorStoreIndex
            index = VectorStoreIndex.from_documents(
                documents,
                storage_context=storage_context,
                service_context=service_context,
            )
        
        else:
            
            ########################################################
            # Use Existing Index
            ########################################################
            main_logger.debug("### Use Existing Index ###")
            
            ###############
            # search_client
            # Use search client to demonstration using existing index
            ###############
            search_client = SearchClient(
                endpoint=service_endpoint,
                index_name=index_name,
                credential=cognitive_search_credential,
            )
            
            ###############
            # vector_store
            ###############
            from llama_index.vector_stores import CognitiveSearchVectorStore
            from llama_index.vector_stores.cogsearch import (
                IndexManagement,
                MetadataIndexFieldType,
                CognitiveSearchVectorStore,
            )
            # metadata_fields = {
            #     "author": "author",
            #     "theme": ("topic", MetadataIndexFieldType.STRING),
            #     "director": "director",
            # }
            vector_store = CognitiveSearchVectorStore(
                search_or_index_client=search_client,
                # filterable_metadata_field_keys=metadata_fields,
                index_management=IndexManagement.NO_VALIDATION,
                id_field_key="id",
                chunk_field_key="content",
                embedding_field_key="embedding",
                metadata_string_field_key="li_jsonMetadata",
                doc_id_field_key="li_doc_id",
            )
            
            ###############
            # storage_context
            ###############
            from llama_index import StorageContext
            storage_context = StorageContext.from_defaults(
                vector_store=vector_store
            )

            ###############
            # service_context
            ###############
            from llama_index.llms import AzureOpenAI
            llm = AzureOpenAI(
                model="gpt-35-turbo",
                engine="gpt-35-turbo-deploy",
                api_key=api_key,
                api_base=api_base,
                api_type=api_type,
                api_version=api_version,
            )

            from llama_index.embeddings import OpenAIEmbedding
            embed_model = OpenAIEmbedding(
                model="text-embedding-ada-002",
                deployment_name="text-embedding-ada-002-deploy", # Azure AI Studioで作成
                api_key=api_key,
                api_base=api_base,
                api_type=api_type,
                api_version=api_version,
            )
            
            from llama_index import ServiceContext
            service_context = ServiceContext.from_defaults(
                llm=llm,
                embed_model=embed_model,
            )

            ###############
            # index
            ###############
            from llama_index import VectorStoreIndex
            index = VectorStoreIndex.from_documents(
                [], 
                storage_context=storage_context, 
                service_context=service_context
            )


        ############################################################################################################
        # Query Engine
        ############################################################################################################
        main_logger.debug("### Query Engine ###")
        
        query_engine = index.as_query_engine()

        from llama_index.tools import QueryEngineTool, ToolMetadata
        from llama_index.query_engine import SubQuestionQueryEngine
        query_engine_tools = [
            QueryEngineTool(
                query_engine=query_engine,
                metadata=ToolMetadata(
                    name="sports", description="sports festivals"
                ),
            ),
        ]
        subquery_engine = SubQuestionQueryEngine.from_defaults(
            query_engine_tools=query_engine_tools,
            service_context=service_context,
            use_async=True,
        )


        ############################################################################################################
        # question
        ############################################################################################################
        main_logger.debug("### question ###")
        
        # query = "What is most interesting about this essay?"
        # query = "2022年サッカーワールドカップと2023年WBCと2023年バスケワールドカップにおいて,それぞれ優勝国について教えてください"
        # query = "2022年サッカーワールドカップと2023年WBCと2023年バスケワールドカップにおいて,開催国と優勝国とMVPについて教えてください"
        # query = "2023年WBCの優勝国はどこですか？"
        # query = "2022年サッカーワールドカップのMVPは誰ですか？"
        # query = "この回答を英語に翻訳してください"
        # query = "産前産後の休業は何日取得できますか？"
        
        question = history[-1]["user"]

        main_logger.debug('question - {} - {}'.format(type(question), question))


        ############################################################################################################
        # Query
        ############################################################################################################
        main_logger.debug("### Query ###")
        
        # response = query_engine.query(question)
        response = subquery_engine.query(question)
        
        main_logger.debug('response - {} - {}'.format(type(response), response))


        ############################################################################################################
        # response
        ############################################################################################################
        main_logger.debug("### response ###")
        
        # 回答の内容
        main_logger.debug('response.response - {} - {}'.format(type(response.response), response.response))

        # 情報ソース
        main_logger.debug('len(response.source_nodes) - {} - {}'.format(type(len(response.source_nodes)), len(response.source_nodes)))
        main_logger.debug('response.source_nodes - {} - {}'.format(type(response.source_nodes), response.source_nodes))
        main_logger.debug('response.get_formatted_sources() - {} - {}'.format(type(response.get_formatted_sources()), response.get_formatted_sources()))


        ############################################################################################################
        # Returns
        ############################################################################################################
        main_logger.debug("### Returns ###")
        
        response_text = response.response + "[test1.txt][test2.pdf]"  # チャットの回答
        msg_to_display = "dummy of msg_to_display"  # 思考プロセス  Search for:
        query_text = "dummy of query_text" # 思考プロセス  Conversations:
        results = ['00001.pdf: AAAAA','00002.pdf: BBBBB','00003.pdf: CCCCC',]  # 補助資料
        
        main_logger.debug('results - {} - {}'.format(type(results), results))
        main_logger.debug('msg_to_display - {} - {}'.format(type(msg_to_display), msg_to_display))
        main_logger.debug('query_text - {} - {}'.format(type(query_text), query_text))
        main_logger.debug('response_text - {} - {}'.format(type(response_text), response_text))
        
        return {"data_points": results, "answer": response_text, "thoughts": f"Searched for:<br>{query_text}<br><br>Conversations:<br>" + msg_to_display.replace('\n', '<br>')}
        # response_text : チャットの回答
        # query_text : 思考プロセス
        # msg_to_display : 思考プロセス
        # results : 補助資料