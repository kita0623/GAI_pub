
# TODO-------------------------------------------------------
# ◼︎ Constructorに
# ◻︎ 履歴情報 -> historyに勝手に追加するようにはなっている 'user''bot'
# ◻︎ 思考プロセス  Search for:
# ◻︎ 思考プロセス  Conversations:
# ◼︎ 補助資料
# ◻︎ service_contextでチャンク分割ルールの変更
# ◻︎ クエリの使い分け
# ◻︎ indexのdescriptionを指定
# ◻︎ Debug logging


# 必ずSubQuestionQueryでRAGを実施しているが、チャットの内容に応じて会話できるように (元もそうなっている？)
# 英語で回答が返されたら、日本語に翻訳してから返す (Agentはない？本に日本語変換方法のまとめコラムがあった気がする)
# 会話履歴はLangChainのConversationBufferMemoryを使ってみる(OpenAIのモデルにそのまま渡せる形式)
# 会話履歴はCosmosDBに保存しているようなので、トライしてみる (approaches.chatlogging.write_chatlog)
# FoamRecognizer(デフォルトの実装では使用されているよう)
# service_contextでチャンク分割ルールの変更
# ワールドカップwikiのPDFは表で情報が入っているので例を変えた方がよいかも
# -----------------------------------------------------------
# MEMO-------------------------------------------------------
# python3.9のpyenv環境で実行
# openaiのapiは使用しない
# azd up で全デプロイが実施される (Coginitive Searchのインデックス作成も実施される)  indexをazure上で消したらデフォルトのchatreadretrievereadが動かなくなった
# cognitive searchの"Create Index"と"Use Existing Index"の大きな違いは、existing index と index_client
# Use Existing Index"の場合もservice_contextにLLMを指定する必要があった(LlamaIndexのドキュメントのCognitive Searchの例ではLLMの指定はなかったが)
# -----------------------------------------------------------

# SimpleDirectoryReader, VectorStoreIndex, standard_engine -> 'file_name'と'page_label'を取得可能で、Blob Strageのチャンク名を作って読みに行っている
# load_index, standard_engine -> indexにservice_contextの情報がないためかエラーが出る
# 


from logging import getLogger, Formatter, FileHandler, DEBUG, INFO
formatter = Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
file_handler = FileHandler("./approaches/subquestionquery.log")
file_handler.setFormatter(formatter)
logger = getLogger(__name__)
logger.addHandler(file_handler)
logger.setLevel(DEBUG)


from azure.search.documents import SearchClient
from azure.search.documents.models import QueryType
from approaches.approach import Approach
from approaches.chatlogging import write_chatlog, ApproachType
from core.messagebuilder import MessageBuilder
from core.modelhelper import get_gpt_model, get_max_token_from_messages

import nest_asyncio
nest_asyncio.apply()


class ChatReadRetrieveReadApproach(Approach):

    def __init__(self, search_client: SearchClient, sourcepage_field: str, content_field: str):
        logger.debug("### Constructor ###")
        
        ###############
        # service_context
        ###############
        from util.make_service_context import mk_service_context
        service_context = mk_service_context()
        
        logger.debug('service_context - {} - {}'.format(type(service_context), service_context))
        
        
        ###############
        # index
        ###############
        FLAG_CREATE_INDEX = False
        
        if FLAG_CREATE_INDEX:
            
            ###############
            # documents
            ###############
            from util.make_documents import (
                mk_docs_SimpleDirectoryReader,
                mk_docs_AzStorageBlobReader,
            )
            documents = mk_docs_SimpleDirectoryReader()
            # documents = mk_docs_AzStorageBlobReader()
            
            logger.debug('len(documents) - {} - {}'.format(type(len(documents)), len(documents)))
            # logger.debug('documents - {} - {}'.format(type(documents), documents))
            
            ###############
            # create index
            ###############
            from util.make_index import (
                mk_sv_idx_VectorStoreIndex,
                mk_idx_CognitiveSearch,
            )
            index = mk_sv_idx_VectorStoreIndex(documents, service_context)
            # index = mk_idx_CognitiveSearch(documents, service_context)
            
        else:
            
            ###############
            # load index
            ###############
            from util.make_index import (
                ld_idx_VectorStoreIndex,
                ld_idx_CognitiveSearch,
            )
            # index = ld_idx_VectorStoreIndex()  # indexにservice_contextの情報がないためかエラーが出る
            index = ld_idx_CognitiveSearch(service_context)
        
        logger.debug('index - {} - {}'.format(type(index), index))


        ###############
        # enigne
        ###############
        from util.make_engine import (
            mk_standard_engine,
            mk_subquestionquery_engine,
        )
        # engine = mk_standard_engine(index)
        engine = mk_subquestionquery_engine(index, service_context)
        
        logger.debug('engine - {} - {}'.format(type(engine), engine))
        
        
        # self.service_context = service_context
        # self.index = index
        self.engine = engine
    
    
    def run(self, user_name: str, history: list[dict], overrides: dict) -> any:
        logger.debug("### run ###")

        ###############
        # question
        ###############        
        # question = "What is most interesting about this essay?"
        # question = "2022年サッカーワールドカップと2023年WBCと2023年バスケワールドカップにおいて,それぞれ優勝国について教えてください"
        # question = "2022年サッカーワールドカップと2023年WBCと2023年バスケワールドカップにおいて,開催国と優勝国とMVPについて教えてください"
        # question = "2023年WBCの優勝国はどこですか？"
        # question = "2022年サッカーワールドカップのMVPは誰ですか？"
        # question = "この回答を英語に翻訳してください"
        # question = "産前産後の休業は何日取得できますか？"
        # question = "これらを要約してください"
        
        question = history[-1]["user"]
        logger.debug('history - {} - {}'.format(type(history), history))
        logger.debug('question - {} - {}'.format(type(question), question))


        ###############
        # query
        ###############
        response = self.engine.query(question)
        logger.debug('response - {} - {}'.format(type(response), response))


        ###############
        # response
        ###############       
        logger.debug('response.response - {} - {}'.format(type(response.response), response.response))
        
        
        ###############
        # source_nodes
        ###############
        logger.debug('len(response.source_nodes) - {} - {}'.format(type(len(response.source_nodes)), len(response.source_nodes)))
        logger.debug('response.source_nodes - {} - {}'.format(type(response.source_nodes), response.source_nodes))
        try:
            logger.debug('response.source_nodes[0] - {} - {}'.format(type(response.source_nodes[0]), response.source_nodes[0]))
            logger.debug('response.source_nodes[0].node - {} - {}'.format(type(response.source_nodes[0].node), response.source_nodes[0].node))
            logger.debug("response.source_nodes[0].node.metadata['file_name'] - {} - {}".format(type(response.source_nodes[0].node.metadata['file_name']), response.source_nodes[0].node.metadata['file_name']))
        except TypeError:
            # SubQuestionQueryEngineの場合はresponse.source_nodesの各要素のscoreがNoneになっており、llama_index/schema.pyの部分でエラーを吐いている
            pass
        

        ###############
        # Process
        ###############
        
        #
        # response_text (チャットの回答 : response_text)
        #
        response_text = response.response
        
        # 引用を追加
        try:
            for i in range(len(response.source_nodes)):
                pdfname_org = response.source_nodes[i].node.metadata['file_name']
                page_label = response.source_nodes[i].node.metadata['page_label']
                pdfname_chunk = f"{pdfname_org.split('.pdf')[0]}-{page_label}.pdf"
                response_text += f"[{pdfname_chunk}]"
        except KeyError:
            # SubQuestionQueryEngineの場合
            pass
        
        
        #
        # query_text (思考プロセス/Search for/検索用語)
        # 
        query_text = question
        
        
        #
        # msg_to_display (思考プロセス/Conversations/systemプロンプト&userプロンプト)
        #
        msg_to_display = "dummy of msg_to_display"
        
        
        #
        # results (補助資料)
        #
        # results = ['001018385-60.pdf: AAAAA','2022_FIFAサッカーワールドカップ-10.pdf: BBBBB','00003.pdf: CCCCC']
        results = []
        for i in range(len(response.source_nodes)):
            try:
                pdfname_org = response.source_nodes[i].node.metadata['file_name']
                page_label = response.source_nodes[i].node.metadata['page_label']
                pdfname_chunk = f"{pdfname_org.split('.pdf')[0]}-{page_label}.pdf"
            except KeyError:
                # pdfname_chunk = f"dummy{i}.pdf"
                pdfname_chunk = f"サブクエスチョン{i}" # 現状サブクエリの場合は文献が取れないので代用
            text = response.source_nodes[i].node.text
            results.append(f"{pdfname_chunk}: {text}")
        
        
        ###############
        # Returns
        ###############
        logger.debug('results - {} - {}'.format(type(results), results))
        logger.debug('msg_to_display - {} - {}'.format(type(msg_to_display), msg_to_display))
        logger.debug('query_text - {} - {}'.format(type(query_text), query_text))
        logger.debug('response_text - {} - {}'.format(type(response_text), response_text))
        
        return {"data_points": results, "answer": response_text, "thoughts": f"Searched for:<br>{query_text}<br><br>Conversations:<br>" + msg_to_display.replace('\n', '<br>')}
        # response_text : チャットの回答
        # query_text : 思考プロセス/Search for/検索用語
        # msg_to_display : 思考プロセス/Conversations/systemプロンプト&userプロンプト
        # results : 補助資料