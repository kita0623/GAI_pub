# from logging import getLogger
# logger = getLogger(__name__)

import os

from azure.core.credentials import AzureKeyCredential
search_service_name = os.environ["RG_TEST_KITAMOTO_SUBQUESTIONQUERY_COGNITIVE_SEARCH_NAME"] # 設定したCognitive Searchのサービス名
key = os.environ["RG_TEST_KITAMOTO_SUBQUESTIONQUERY_COGNITIVE_SEARCH_KEY"]
cognitive_search_credential = AzureKeyCredential(key)
service_endpoint = f"https://{search_service_name}.search.windows.net"
index_name = "indextest"


def mk_sv_idx_VectorStoreIndex(documents, service_context):
    """Create Index (VectorStoreIndex)
    
    Args:
        documents
        service_context

    Returns:
        index
    """
    
    ###############
    # storage_context
    ###############
    storage_context = None
    
    ###############
    # indexを作成
    ###############
    from llama_index import VectorStoreIndex
    index = VectorStoreIndex.from_documents(
        documents=documents,
        service_context=service_context,
        storage_context=storage_context
    )
    
    ###############
    # indexを保存 (storage_context 生成)
    ###############
    index.storage_context.persist(persist_dir="./index/")
    
    return index


# Azure上ではエラー 以前できた気がするので要確認
# indexの読み込みはできているようだが、queryの際にAzure API関連でエラー (保存するindexにAzureのcredential情報がないため？)
# indexにservice_contextの情報を持たせる必要がある？
# openai.error.InvalidRequestError: Must provide an 'engine' or 'deployment_id' parameter to create a <class 'openai.api_resources.embedding.Embedding'>
def ld_idx_VectorStoreIndex():
    """Use Existing Index (VectorStoreIndex)
    
    Args:

    Returns:
        index
    """
    
    ###############
    # storage_context
    ###############
    from llama_index import StorageContext
    storage_context = StorageContext.from_defaults(persist_dir="./index/")
    
    ###############
    # indexをロード
    ###############
    from llama_index import load_index_from_storage
    index = load_index_from_storage(storage_context)
    
    return index


def mk_idx_CognitiveSearch(documents, service_context):
    """Create Index (Cognitive Search)
    
    Args:
        documents
        service_context

    Returns:
        index
    """
    
    ###############
    # index_client
    ###############
    from azure.search.documents.indexes import SearchIndexClient
    index_client = SearchIndexClient(
        credential=cognitive_search_credential,
        endpoint=service_endpoint,
    )
    
    ###############
    # vector_store
    ###############
    from llama_index.vector_stores import CognitiveSearchVectorStore
    from llama_index.vector_stores.cogsearch import (
        IndexManagement,
        MetadataIndexFieldType,
        CognitiveSearchVectorStore,
    )
    # # Example of a complex mapping, metadata field 'theme' is mapped to a differently name index field 'topic' with its type explicitly set
    # metadata_fields = {
    #     "author": "author",
    #     "theme": ("topic", MetadataIndexFieldType.STRING),
    #     "director": "director",
    # }

    # A simplified metadata specification is available if all metadata and index fields are similarly named
    # metadata_fields = {"author", "theme", "director"}
    vector_store = CognitiveSearchVectorStore(
        search_or_index_client=index_client,
        index_name=index_name,
        # filterable_metadata_field_keys=metadata_fields,
        index_management=IndexManagement.CREATE_IF_NOT_EXISTS,
        id_field_key="id",
        chunk_field_key="content",
        embedding_field_key="embedding",
        metadata_string_field_key="li_jsonMetadata",
        doc_id_field_key="li_doc_id",
    )
    
    ###############
    # storage_context
    ###############
    from llama_index import StorageContext
    storage_context = StorageContext.from_defaults(
        vector_store=vector_store
    )

    ###############
    # index
    ###############
    from llama_index import VectorStoreIndex
    index = VectorStoreIndex.from_documents(
        documents,
        storage_context=storage_context,
        service_context=service_context,
    )
    
    return index


def ld_idx_CognitiveSearch(service_context):
    """Use Existing Index (Cognitive Search)
    
    Args:
        service_context
    Returns:
        index
    """
    
    ###############
    # search_client
    # Use search client to demonstration using existing index
    ###############
    from azure.search.documents import SearchClient
    search_client = SearchClient(
        endpoint=service_endpoint,
        index_name=index_name,
        credential=cognitive_search_credential,
    )
    
    ###############
    # vector_store
    ###############
    from llama_index.vector_stores import CognitiveSearchVectorStore
    from llama_index.vector_stores.cogsearch import (
        IndexManagement,
        MetadataIndexFieldType,
        CognitiveSearchVectorStore,
    )
    # metadata_fields = {
    #     "author": "author",
    #     "theme": ("topic", MetadataIndexFieldType.STRING),
    #     "director": "director",
    # }
    vector_store = CognitiveSearchVectorStore(
        search_or_index_client=search_client,
        # filterable_metadata_field_keys=metadata_fields,
        index_management=IndexManagement.NO_VALIDATION,
        id_field_key="id",
        chunk_field_key="content",
        embedding_field_key="embedding",
        metadata_string_field_key="li_jsonMetadata",
        doc_id_field_key="li_doc_id",
    )
    
    ###############
    # storage_context
    ###############
    from llama_index import StorageContext
    storage_context = StorageContext.from_defaults(
        vector_store=vector_store
    )
    
    ###############
    # index
    ###############
    from llama_index import VectorStoreIndex
    index = VectorStoreIndex.from_documents(
        [], 
        storage_context=storage_context, 
        service_context=service_context
    )
    
    return index