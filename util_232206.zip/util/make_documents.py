# from logging import getLogger
# logger = getLogger(__name__)


def mk_docs_SimpleDirectoryReader():
    from llama_index import SimpleDirectoryReader
    documents = SimpleDirectoryReader("../../data/").load_data()
    return documents


def mk_docs_AzStorageBlobReader():
    from llama_index import download_loader
    from azure.identity import DefaultAzureCredential
    default_credential = DefaultAzureCredential()
    AzStorageBlobReader = download_loader("AzStorageBlobReader")
    loader = AzStorageBlobReader(container_name='content', account_url='https://stjvuf7knsnar76.blob.core.windows.net', credential=default_credential)
    documents = loader.load_data()
    return documents