# from logging import getLogger
# logger = getLogger(__name__)


def mk_standard_engine(index):
    """Create Standard Query Engine

    Args:
        index
        
    Returns:
        engine
    """
    
    engine = index.as_query_engine()
    return engine


def mk_subquestionquery_engine(index, service_context):
    """Create SubQuestionQuery Engine

    Args:
        index
        service_context
        
    Returns:
        engine
    """
    
    from llama_index.tools import QueryEngineTool, ToolMetadata
    from llama_index.query_engine import SubQuestionQueryEngine
    query_engine_tools = [
        QueryEngineTool(
            query_engine=index.as_query_engine(),
            metadata=ToolMetadata(
                name="sports",
                description="sports festivals"
            ),
        ),
    ]
    engine = SubQuestionQueryEngine.from_defaults(
        query_engine_tools=query_engine_tools,
        service_context=service_context,
        use_async=True,
    )
    return engine