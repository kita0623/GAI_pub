# from logging import getLogger
# logger = getLogger(__name__)


api_key = "ebcc1cf3327842698dfce603cc9a58a8"
api_base = "https://cog-jvuf7knsnar76.openai.azure.com/"
api_type = "azure"
api_version = "2023-09-15-preview"


def mk_service_context():
    
    from llama_index.llms import AzureOpenAI
    llm = AzureOpenAI(
        model="gpt-35-turbo",
        engine="gpt-35-turbo-deploy",
        api_key=api_key,
        api_base=api_base,
        api_type=api_type,
        api_version=api_version,
    )

    from llama_index.embeddings import OpenAIEmbedding
    embed_model = OpenAIEmbedding(
        model="text-embedding-ada-002",
        deployment_name="text-embedding-ada-002-deploy", # Azure AI Studioで作成
        api_key=api_key,
        api_base=api_base,
        api_type=api_type,
        api_version=api_version,
    )

    from llama_index import ServiceContext
    service_context = ServiceContext.from_defaults(
        llm=llm,
        embed_model=embed_model,
        # prompt_helper でチャンク分割ルールの変更も可能
    )
    
    return service_context